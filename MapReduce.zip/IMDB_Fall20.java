import java.io.*;
import java.util.*;

import org.apache.hadoop.conf.*;
import org.apache.hadoop.util.*;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.*;
import org.apache.hadoop.mapreduce.lib.output.*;

public class IMDB_Fall20 {
  public static class TitleMapper extends Mapper<Object, Text, Text, Text> {
    public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
      String[] tokens = value.toString().split("\t");
      String titleID = tokens[0];
      String titleType = tokens[1];
      String titleName = tokens[2];
      String releaseYear = tokens[5];
      String geners = tokens[8];
      if (releaseYear.length() < 4 || !titleType.equals("tvEpisode")
          || (Integer.parseInt(releaseYear) < 1960 || Integer.parseInt(releaseYear) > 1970)) {
        return;
      }

      String _key = titleID;
      String _value = "1\t" + titleType + "\t" + titleName + "\t" + releaseYear + "\t" + geners;
      context.write(new Text(_key), new Text(_value));
    }
  }

  public static class ActorMapper extends Mapper<Object, Text, Text, Text> {
    public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
      String[] tokens = value.toString().split(",");
      String titleID = tokens[0];
      String actorID = tokens[1];
      String actorName = tokens[2];

      String _key = titleID;
      String _value = "2\t" + actorID + "\t" + actorName;
      context.write(new Text(_key), new Text(_value));
    }
  }

  public static class DirectorMapper extends Mapper<Object, Text, Text, Text> {
    public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
      String[] tokens = value.toString().split("\t");
      String titleID = tokens[0];
      String[] directorIDs = tokens[1].split(",");
      for (String directorID : directorIDs) {
        String _key = titleID;
        String _value = "3\t" + directorID;
        context.write(new Text(_key), new Text(_value));
      }
    }
  }

  public static class DirActComb extends Reducer<Text, Text, Text, Text> {
    public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
      ArrayList<String> titleInfo = new ArrayList<>();
      ArrayList<String> actorInfo = new ArrayList<>();
      ArrayList<String> directorInfo = new ArrayList<>();
      for (Text value : values) {
        String[] tokens = value.toString().split("\t");
        if (tokens[0].equals("1")) {
          titleInfo.add(tokens[1] + "\t" + tokens[2] + "\t" + tokens[3] + "\t" + tokens[4]);
        } else if (tokens[0].equals("2")) {
          actorInfo.add(tokens[1] + "\t" + tokens[2]);
        } else if (tokens[0].equals("3")) {
          directorInfo.add(tokens[1]);
        }
      }

      if (titleInfo.size() == 0) {
        return;
      }

      String title_info = titleInfo.get(0);
      String[] title_tokens = title_info.split("\t");
      for (String actor : actorInfo) {
        for (String director : directorInfo) {
          String[] actor_tokens = actor.split("\t");
          String[] director_tokens = director.split("\t");

          if (actor_tokens[0].equals(director_tokens[0])) {
            String _key = title_tokens[1] + "\t" + actor_tokens[1] + "\t" + title_tokens[3] + "\t" + title_tokens[2];
            context.write(new Text(_key), new Text());
          }
        }
      }
    }
  }

  public static void main(String[] args) throws Exception {
    // change config here
    int reduernum = 2;

    Configuration conf = new Configuration();
    int split = 700 * 1024 * 1024;
    String splitsize = Integer.toString(split);
    conf.set("mapreduce.input.fileinputformat.split.minsize", splitsize);
    conf.set("mapreduce.map.memory.mb", "2048");
    conf.set("mapreduce.reduce.memory.mb", "2048");
    Job job1 = Job.getInstance(conf, "actor-director gig");
    job1.setJarByClass(IMDB_Fall20.class);
    job1.setNumReduceTasks(reduernum);
    MultipleInputs.addInputPath(job1, new Path(args[0]), TextInputFormat.class, TitleMapper.class);
    MultipleInputs.addInputPath(job1, new Path(args[1]), TextInputFormat.class, ActorMapper.class);
    MultipleInputs.addInputPath(job1, new Path(args[2]), TextInputFormat.class, DirectorMapper.class);
    job1.setReducerClass(DirActComb.class);
    job1.setMapOutputKeyClass(Text.class);
    job1.setMapOutputValueClass(Text.class);
    job1.setOutputValueClass(Text.class);
    job1.setOutputKeyClass(Text.class);
    FileOutputFormat.setOutputPath(job1, new Path(args[3] + "inter"));
    job1.waitForCompletion(true);
    System.exit(0);
  }
}